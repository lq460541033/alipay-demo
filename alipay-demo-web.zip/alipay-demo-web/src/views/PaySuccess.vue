<template>
  <div class="main">
      <h1>支付成功后回调的页面！</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {
  
   
    };
  },
  methods: {
  },
};
</script>

<style scoped>

</style>